$(document).ready(function () {
	$('#search, .fa-search').mouseenter(function () { 
		$('.logo').hide();
	});
	$('#search, .fa-search').mouseleave(function () { 
		$('.logo').show();
	});
	$('#header .fa-bars').click(function (e) { 
		$('#header .navbar').toggle();
		$(this).toggleClass('#header .fa-times');
	});
	$('#header .navbar, #header .navbar a').click(function (e) { 
		$('#header .navbar').hide();
		$('#header .fa-bars').removeClass('#header .fa-times');
	});
	$('.home-slider').owlCarousel({
		loop:true,
		margin:10,
		nav:true,
		items:1,
		autoplay: true
	});
	$('.product-slider').owlCarousel({
		loop:true,
		margin:10,
		nav:true,
		items:3,
		autoplay: true,
		center: true,
		responsive:{
			0:{
				items:1,
				nav:true
			},
			550:{
				items:2
			},
			1000:{
				items:3
			}
		}
	});
});